package code;



import java.sql.Connection;
import java.sql.DriverManager;

public class DataBaseConnection
{
	final static private String myurl="jdbc:mysql://localhost:3306/";
	final static private String mydrivar="com.mysql.jdbc.Driver";
	final static private String mydb="Hospital_Management";
	final static private String password="root";
	final static private String username="root";
	
	private static DataBaseConnection instance = new DataBaseConnection();
	
	private DataBaseConnection(){	
		try{
			Class.forName(mydrivar);
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
	}
	
	private Connection createConnection()
	{
		Connection conn=null;
		try
		{
			conn = DriverManager.getConnection(myurl + mydb+"?characterEncoding=UTF-8",username,password);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return conn;
	}

	public static Connection JAVAConnection()
	{		
		return instance.createConnection();
	}

}











