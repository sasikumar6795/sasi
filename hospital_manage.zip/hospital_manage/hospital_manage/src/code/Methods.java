package code;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Methods {
	static int i=0;
	public String add_pat(int pat_id,String pat_Name,String address,
	String complnt,String amt,String contact,String doc_name,String pat_type){
		Connection cnt=DataBaseConnection.JAVAConnection();
		try {
			Statement stt=cnt.createStatement();
			System.out.println("It is in add aptient ");
			System.out.println(pat_id+" "+pat_Name+" "+address+" "+complnt+" "+amt+" "+contact+" "+doc_name+" "+pat_type);
			String qq="insert into Patient (PatientId,PatientName,Address,Complaint,Amountpaid,Contactnumber,DoctorName,Patient_type) values ('"+pat_id+"','"+pat_Name+"','"+address+"','"+complnt+"','"+amt+"','"+contact+"','"+doc_name+"','"+pat_type+"')";
		//PatientId, PatientName, Address, Complaint, Amountpaid, Contactnumber, DoctorName, Patient_type
			
			
			int p=stt.executeUpdate(qq);
			if(p==1){
				return "Patient added successfully";
			}
			else{
				return "any problem occurred while inserting patient";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		return "";
		
	}
public Patient1 view_pat(int pat_id){
	//ArrayList<Patient> arList = new ArrayList<Patient>();
	Patient1 p=new Patient1();
	Connection cnt=DataBaseConnection.JAVAConnection();
		
						try {
							Statement stt=cnt.createStatement();
							System.out.println("It is in view aptient with pat_id="+pat_id);
							//System.out.println(pat_id+" "+pat_Name+" "+address+" "+complnt+" "+amt+" "+contact+" "+doc_name+" "+pat_type);
							String qq="select * from patient where PatientId='"+pat_id+"' ";
							ResultSet rr=stt.executeQuery(qq);
							//int i=1;
							while(rr.next())
							{
								//Patient1 p=new Patient1();
								p.setPatient_Name(rr.getString("PatientName"));
								System.out.println("pat_name retrieve "+rr.getString("PatientName"));
								System.out.println("pat_name got is "+p.getPatient_Name());
								p.setAddress(rr.getString("Address"));
								p.setComplaint(rr.getString("Complaint"));
								p.setAmount_paid(rr.getString("Amountpaid"));
								p.setContact_number(rr.getString("Contactnumber"));
								p.setDoctor_Name(rr.getString("DoctorName"));
								p.setPat_Type(rr.getString("Patient_type"));
								//arList.add(p);
							//	i++;
								System.out.println("address of patient p is "+p);
								
							}
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					return p;
				}
	public int create_Id(String pat_name){
		System.out.println("In create Id "+"pat name is "+pat_name);
		int pat_id=++i ;
		
		System.out.println("pat id is "+pat_id);
		return pat_id;
	}
	public ArrayList<String> getAllPat_name(){
		ArrayList<String> arPat_name=new ArrayList<String>();
		try {
			Connection cnt=DataBaseConnection.JAVAConnection();
			Statement stt=cnt.createStatement();
			System.out.println("It is getting all names");
			String qq="select PatientName from Patient";
			ResultSet rr=stt.executeQuery(qq);
			while(rr.next())
			{
				String pat_name=rr.getString("PatientName");
				arPat_name.add(pat_name);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return arPat_name;
	}
	public int deleteByName(String Pat_name){
		Connection cnt=DataBaseConnection.JAVAConnection();
		int p=0;
		try {
			Statement stt=cnt.createStatement();
			String qq="delete from patient where PatientName='"+Pat_name+"' and Patient_type='Out_patient'";
			p = stt.executeUpdate(qq);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return p;
	}
	public void Trial(){
		System.out.println("In method ");
	}
}
