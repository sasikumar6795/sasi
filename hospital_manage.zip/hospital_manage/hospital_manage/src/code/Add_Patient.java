package code;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Add_Patient
 */
public class Add_Patient extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Add_Patient() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Methods m=new Methods();
		String pat_Name=request.getParameter("pat_name");
		int pat_id=m.create_Id(pat_Name);
		String address=request.getParameter("address");
		String complnt=request.getParameter("complnt");
		String amt=request.getParameter("amt");
		String contact=request.getParameter("contact");
		String doc_name=request.getParameter("doc_name");
		String pat_type=request.getParameter("pat_type");
	//	System.out.println(pat_Name);
		String status=m.add_pat(pat_id, pat_Name, address, complnt, amt, contact, doc_name, pat_type);
		if(status.equals("Patient added successfully")){
			response.sendRedirect("addSuccess.jsp");
		}
		else if(status.equals("any problem occurred while inserting patient")){
			response.sendRedirect("addFailure.jsp");
		}
		
		System.out.println(status);
		//System.out.println("pat_id " +pat_id);
	/*	System.out.println("address " +address);
		System.out.println("complnt " +complnt);
		System.out.println("amt " +amt);
		System.out.println("contact " +contact);
		System.out.println("doc_name " +doc_name);
		System.out.println("pat_type "+pat_type);*/
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
