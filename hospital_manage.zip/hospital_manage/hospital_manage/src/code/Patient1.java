package code;

public class Patient1 {
	//int	Patient_Id;
	String Patient_Name;
	String Address;
	String Complaint;
	String Amount_paid;
	String Contact_number;
	String Doctor_Name;
	String Pat_Type;
	/*public int getPatient_Id() {
		return Patient_Id;
	}
	public void setPatient_Id(int patient_Id) {
		Patient_Id = patient_Id;
	}*/
	public String getPatient_Name() {
		return Patient_Name;
	}
	public void setPatient_Name(String patient_Name) {
		Patient_Name = patient_Name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getComplaint() {
		return Complaint;
	}
	public void setComplaint(String complaint) {
		Complaint = complaint;
	}
	public String getAmount_paid() {
		return Amount_paid;
	}
	public void setAmount_paid(String amount_paid) {
		Amount_paid = amount_paid;
	}
	public String getContact_number() {
		return Contact_number;
	}
	public void setContact_number(String contact_number) {
		Contact_number = contact_number;
	}
	public String getDoctor_Name() {
		return Doctor_Name;
	}
	public void setDoctor_Name(String doctor_Name) {
		Doctor_Name = doctor_Name;
	}
	public String getPat_Type() {
		return Pat_Type;
	}
	public void setPat_Type(String pat_Type) {
		Pat_Type = pat_Type;
	}

}
